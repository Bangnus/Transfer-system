--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg120+1)
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE transfer;
--
-- Name: transfer; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE transfer WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE transfer OWNER TO root;

\connect transfer

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: root
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO root;

--
-- Name: TransferStatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."TransferStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."TransferStatus" OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Course" (
    id integer NOT NULL,
    "courseCode" text NOT NULL,
    "courseNameTH" text NOT NULL,
    "courseNameENG" text NOT NULL,
    "prerequisiteTH" text,
    "prerequisiteENG" text,
    credit integer NOT NULL,
    "descriptionTH" text,
    "descriptionENG" text,
    "groupId" integer NOT NULL
);


ALTER TABLE public."Course" OWNER TO root;

--
-- Name: CourseTransfer; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."CourseTransfer" (
    id integer NOT NULL,
    "originalCourseId" integer,
    "transferredCourseId" integer,
    "specialtransferredCourseId" integer,
    description text,
    status public."TransferStatus" DEFAULT 'PENDING'::public."TransferStatus",
    "dateSubmitted" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CourseTransfer" OWNER TO root;

--
-- Name: CourseTransfer_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."CourseTransfer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CourseTransfer_id_seq" OWNER TO root;

--
-- Name: CourseTransfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."CourseTransfer_id_seq" OWNED BY public."CourseTransfer".id;


--
-- Name: Course_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Course_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Course_id_seq" OWNER TO root;

--
-- Name: Course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Course_id_seq" OWNED BY public."Course".id;


--
-- Name: Departments; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Departments" (
    id integer NOT NULL,
    depcode text NOT NULL,
    depname text NOT NULL,
    seccode text NOT NULL,
    secname text NOT NULL,
    faccode text NOT NULL
);


ALTER TABLE public."Departments" OWNER TO root;

--
-- Name: Departments_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Departments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Departments_id_seq" OWNER TO root;

--
-- Name: Departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Departments_id_seq" OWNED BY public."Departments".id;


--
-- Name: Faculties; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Faculties" (
    id integer NOT NULL,
    faccode text NOT NULL,
    facname text NOT NULL
);


ALTER TABLE public."Faculties" OWNER TO root;

--
-- Name: Faculties_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Faculties_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Faculties_id_seq" OWNER TO root;

--
-- Name: Faculties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Faculties_id_seq" OWNED BY public."Faculties".id;


--
-- Name: Group; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Group" (
    id integer NOT NULL,
    name text NOT NULL,
    "subjectCategoryId" integer NOT NULL
);


ALTER TABLE public."Group" OWNER TO root;

--
-- Name: Group_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Group_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Group_id_seq" OWNER TO root;

--
-- Name: Group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Group_id_seq" OWNED BY public."Group".id;


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Notification" (
    id integer NOT NULL,
    message text,
    "isRead" boolean DEFAULT false NOT NULL,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "StdCourseId" integer
);


ALTER TABLE public."Notification" OWNER TO root;

--
-- Name: Notification_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Notification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notification_id_seq" OWNER TO root;

--
-- Name: Notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Notification_id_seq" OWNED BY public."Notification".id;


--
-- Name: SpecialCourse; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."SpecialCourse" (
    id integer NOT NULL,
    "courseCode" text NOT NULL,
    "courseNameTH" text NOT NULL,
    "courseNameENG" text NOT NULL,
    "prerequisiteTH" text,
    "prerequisiteENG" text,
    credit text,
    "descriptionTH" text,
    "descriptionENG" text,
    "SubSpecialtyGroupID" integer
);


ALTER TABLE public."SpecialCourse" OWNER TO root;

--
-- Name: SpecialCourse_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."SpecialCourse_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SpecialCourse_id_seq" OWNER TO root;

--
-- Name: SpecialCourse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."SpecialCourse_id_seq" OWNED BY public."SpecialCourse".id;


--
-- Name: SpecialGroup; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."SpecialGroup" (
    id integer NOT NULL,
    name text NOT NULL,
    "SubjectCategoryID" integer NOT NULL,
    secname text
);


ALTER TABLE public."SpecialGroup" OWNER TO root;

--
-- Name: SpecialGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."SpecialGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SpecialGroup_id_seq" OWNER TO root;

--
-- Name: SpecialGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."SpecialGroup_id_seq" OWNED BY public."SpecialGroup".id;


--
-- Name: StudentCourse; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."StudentCourse" (
    id integer NOT NULL,
    "courseCode" text,
    "courseName" text NOT NULL,
    credit text,
    grade text,
    description text,
    "usernameId" text
);


ALTER TABLE public."StudentCourse" OWNER TO root;

--
-- Name: StudentCourse_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."StudentCourse_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudentCourse_id_seq" OWNER TO root;

--
-- Name: StudentCourse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."StudentCourse_id_seq" OWNED BY public."StudentCourse".id;


--
-- Name: SubSpecialtyGroup; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."SubSpecialtyGroup" (
    id integer NOT NULL,
    name text NOT NULL,
    "SpecialGroupID" integer
);


ALTER TABLE public."SubSpecialtyGroup" OWNER TO root;

--
-- Name: SubSpecialtyGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."SubSpecialtyGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SubSpecialtyGroup_id_seq" OWNER TO root;

--
-- Name: SubSpecialtyGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."SubSpecialtyGroup_id_seq" OWNED BY public."SubSpecialtyGroup".id;


--
-- Name: SubjectCategory; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."SubjectCategory" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."SubjectCategory" OWNER TO root;

--
-- Name: SubjectCategory_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."SubjectCategory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SubjectCategory_id_seq" OWNER TO root;

--
-- Name: SubjectCategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."SubjectCategory_id_seq" OWNED BY public."SubjectCategory".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    cid text,
    username text,
    name text,
    firstname text,
    lastname text,
    type text,
    faccode text,
    facname text,
    depcode text,
    depname text,
    seccode text,
    secname text,
    email text
);


ALTER TABLE public."Users" OWNER TO root;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_id_seq" OWNER TO root;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO root;

--
-- Name: Course id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Course" ALTER COLUMN id SET DEFAULT nextval('public."Course_id_seq"'::regclass);


--
-- Name: CourseTransfer id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."CourseTransfer" ALTER COLUMN id SET DEFAULT nextval('public."CourseTransfer_id_seq"'::regclass);


--
-- Name: Departments id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Departments" ALTER COLUMN id SET DEFAULT nextval('public."Departments_id_seq"'::regclass);


--
-- Name: Faculties id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Faculties" ALTER COLUMN id SET DEFAULT nextval('public."Faculties_id_seq"'::regclass);


--
-- Name: Group id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Group" ALTER COLUMN id SET DEFAULT nextval('public."Group_id_seq"'::regclass);


--
-- Name: Notification id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Notification" ALTER COLUMN id SET DEFAULT nextval('public."Notification_id_seq"'::regclass);


--
-- Name: SpecialCourse id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialCourse" ALTER COLUMN id SET DEFAULT nextval('public."SpecialCourse_id_seq"'::regclass);


--
-- Name: SpecialGroup id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialGroup" ALTER COLUMN id SET DEFAULT nextval('public."SpecialGroup_id_seq"'::regclass);


--
-- Name: StudentCourse id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentCourse" ALTER COLUMN id SET DEFAULT nextval('public."StudentCourse_id_seq"'::regclass);


--
-- Name: SubSpecialtyGroup id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SubSpecialtyGroup" ALTER COLUMN id SET DEFAULT nextval('public."SubSpecialtyGroup_id_seq"'::regclass);


--
-- Name: SubjectCategory id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SubjectCategory" ALTER COLUMN id SET DEFAULT nextval('public."SubjectCategory_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Course" (id, "courseCode", "courseNameTH", "courseNameENG", "prerequisiteTH", "prerequisiteENG", credit, "descriptionTH", "descriptionENG", "groupId") FROM stdin;
\.
COPY public."Course" (id, "courseCode", "courseNameTH", "courseNameENG", "prerequisiteTH", "prerequisiteENG", credit, "descriptionTH", "descriptionENG", "groupId") FROM '$$PATH$$/3489.dat';

--
-- Data for Name: CourseTransfer; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."CourseTransfer" (id, "originalCourseId", "transferredCourseId", "specialtransferredCourseId", description, status, "dateSubmitted") FROM stdin;
\.
COPY public."CourseTransfer" (id, "originalCourseId", "transferredCourseId", "specialtransferredCourseId", description, status, "dateSubmitted") FROM '$$PATH$$/3491.dat';

--
-- Data for Name: Departments; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Departments" (id, depcode, depname, seccode, secname, faccode) FROM stdin;
\.
COPY public."Departments" (id, depcode, depname, seccode, secname, faccode) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: Faculties; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Faculties" (id, faccode, facname) FROM stdin;
\.
COPY public."Faculties" (id, faccode, facname) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: Group; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Group" (id, name, "subjectCategoryId") FROM stdin;
\.
COPY public."Group" (id, name, "subjectCategoryId") FROM '$$PATH$$/3487.dat';

--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Notification" (id, message, "isRead", "userId", "createdAt", "StdCourseId") FROM stdin;
\.
COPY public."Notification" (id, message, "isRead", "userId", "createdAt", "StdCourseId") FROM '$$PATH$$/3493.dat';

--
-- Data for Name: SpecialCourse; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."SpecialCourse" (id, "courseCode", "courseNameTH", "courseNameENG", "prerequisiteTH", "prerequisiteENG", credit, "descriptionTH", "descriptionENG", "SubSpecialtyGroupID") FROM stdin;
\.
COPY public."SpecialCourse" (id, "courseCode", "courseNameTH", "courseNameENG", "prerequisiteTH", "prerequisiteENG", credit, "descriptionTH", "descriptionENG", "SubSpecialtyGroupID") FROM '$$PATH$$/3483.dat';

--
-- Data for Name: SpecialGroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."SpecialGroup" (id, name, "SubjectCategoryID", secname) FROM stdin;
\.
COPY public."SpecialGroup" (id, name, "SubjectCategoryID", secname) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: StudentCourse; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."StudentCourse" (id, "courseCode", "courseName", credit, grade, description, "usernameId") FROM stdin;
\.
COPY public."StudentCourse" (id, "courseCode", "courseName", credit, grade, description, "usernameId") FROM '$$PATH$$/3477.dat';

--
-- Data for Name: SubSpecialtyGroup; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."SubSpecialtyGroup" (id, name, "SpecialGroupID") FROM stdin;
\.
COPY public."SubSpecialtyGroup" (id, name, "SpecialGroupID") FROM '$$PATH$$/3481.dat';

--
-- Data for Name: SubjectCategory; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."SubjectCategory" (id, name) FROM stdin;
\.
COPY public."SubjectCategory" (id, name) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Users" (id, cid, username, name, firstname, lastname, type, faccode, facname, depcode, depname, seccode, secname, email) FROM stdin;
\.
COPY public."Users" (id, cid, username, name, firstname, lastname, type, faccode, facname, depcode, depname, seccode, secname, email) FROM '$$PATH$$/3471.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3469.dat';

--
-- Name: CourseTransfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."CourseTransfer_id_seq"', 21, true);


--
-- Name: Course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Course_id_seq"', 20, true);


--
-- Name: Departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Departments_id_seq"', 1, true);


--
-- Name: Faculties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Faculties_id_seq"', 1, true);


--
-- Name: Group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Group_id_seq"', 4, true);


--
-- Name: Notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Notification_id_seq"', 22, true);


--
-- Name: SpecialCourse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."SpecialCourse_id_seq"', 3, true);


--
-- Name: SpecialGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."SpecialGroup_id_seq"', 3, true);


--
-- Name: StudentCourse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."StudentCourse_id_seq"', 22, true);


--
-- Name: SubSpecialtyGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."SubSpecialtyGroup_id_seq"', 7, true);


--
-- Name: SubjectCategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."SubjectCategory_id_seq"', 2, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Users_id_seq"', 2, true);


--
-- Name: CourseTransfer CourseTransfer_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."CourseTransfer"
    ADD CONSTRAINT "CourseTransfer_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: Departments Departments_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Departments"
    ADD CONSTRAINT "Departments_pkey" PRIMARY KEY (id);


--
-- Name: Faculties Faculties_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Faculties"
    ADD CONSTRAINT "Faculties_pkey" PRIMARY KEY (id);


--
-- Name: Group Group_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: SpecialCourse SpecialCourse_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialCourse"
    ADD CONSTRAINT "SpecialCourse_pkey" PRIMARY KEY (id);


--
-- Name: SpecialGroup SpecialGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialGroup"
    ADD CONSTRAINT "SpecialGroup_pkey" PRIMARY KEY (id);


--
-- Name: StudentCourse StudentCourse_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentCourse"
    ADD CONSTRAINT "StudentCourse_pkey" PRIMARY KEY (id);


--
-- Name: SubSpecialtyGroup SubSpecialtyGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SubSpecialtyGroup"
    ADD CONSTRAINT "SubSpecialtyGroup_pkey" PRIMARY KEY (id);


--
-- Name: SubjectCategory SubjectCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SubjectCategory"
    ADD CONSTRAINT "SubjectCategory_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Departments_depcode_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "Departments_depcode_key" ON public."Departments" USING btree (depcode);


--
-- Name: Departments_seccode_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "Departments_seccode_key" ON public."Departments" USING btree (seccode);


--
-- Name: Faculties_faccode_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "Faculties_faccode_key" ON public."Faculties" USING btree (faccode);


--
-- Name: Users_cid_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "Users_cid_key" ON public."Users" USING btree (cid);


--
-- Name: Users_username_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "Users_username_key" ON public."Users" USING btree (username);


--
-- Name: CourseTransfer CourseTransfer_originalCourseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."CourseTransfer"
    ADD CONSTRAINT "CourseTransfer_originalCourseId_fkey" FOREIGN KEY ("originalCourseId") REFERENCES public."StudentCourse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CourseTransfer CourseTransfer_specialtransferredCourseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."CourseTransfer"
    ADD CONSTRAINT "CourseTransfer_specialtransferredCourseId_fkey" FOREIGN KEY ("specialtransferredCourseId") REFERENCES public."SpecialCourse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CourseTransfer CourseTransfer_transferredCourseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."CourseTransfer"
    ADD CONSTRAINT "CourseTransfer_transferredCourseId_fkey" FOREIGN KEY ("transferredCourseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Course Course_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."Group"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Departments Departments_faccode_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Departments"
    ADD CONSTRAINT "Departments_faccode_fkey" FOREIGN KEY (faccode) REFERENCES public."Faculties"(faccode) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Group Group_subjectCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_subjectCategoryId_fkey" FOREIGN KEY ("subjectCategoryId") REFERENCES public."SubjectCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_StdCourseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_StdCourseId_fkey" FOREIGN KEY ("StdCourseId") REFERENCES public."StudentCourse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(username) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialCourse SpecialCourse_SubSpecialtyGroupID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialCourse"
    ADD CONSTRAINT "SpecialCourse_SubSpecialtyGroupID_fkey" FOREIGN KEY ("SubSpecialtyGroupID") REFERENCES public."SubSpecialtyGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialGroup SpecialGroup_SubjectCategoryID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SpecialGroup"
    ADD CONSTRAINT "SpecialGroup_SubjectCategoryID_fkey" FOREIGN KEY ("SubjectCategoryID") REFERENCES public."SubjectCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StudentCourse StudentCourse_usernameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentCourse"
    ADD CONSTRAINT "StudentCourse_usernameId_fkey" FOREIGN KEY ("usernameId") REFERENCES public."Users"(username) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SubSpecialtyGroup SubSpecialtyGroup_SpecialGroupID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."SubSpecialtyGroup"
    ADD CONSTRAINT "SubSpecialtyGroup_SpecialGroupID_fkey" FOREIGN KEY ("SpecialGroupID") REFERENCES public."SpecialGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

